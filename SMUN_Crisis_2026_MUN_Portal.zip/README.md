# SMUN Crisis 2026 — MUN Management Portal

A GitHub Pages-ready static website for a Model United Nations conference.

## Included

- Home / conference landing page
- Committee backgrounds, agendas and freeze dates
- Delegate country assignment search
- Delegate portal lookup
- Event registration
- Event schedule
- Live update feed
- Organising committee login panel
- Committee resource library
- Client-side combined PDF downloader
- Gmail contact/registration fallback
- Optional Firebase Authentication + Firestore realtime backend

## Important architecture note

GitHub Pages is static hosting. It cannot safely store passwords, process registrations on its own, or provide realtime database updates.

This project therefore has:
1. GitHub Pages → hosts the frontend.
2. Firebase Authentication → secure admin login.
3. Firebase Firestore → registrations, assignments, schedule and live updates.
4. Gmail → conference contact and fallback registration email.

The supplied admin password from the planning brief is NOT embedded in the website. Do not put a real admin password in JavaScript or GitHub.

## Setup for GitHub Pages

1. Create a GitHub repository.
2. Upload all files/folders in this package.
3. Go to Settings → Pages.
4. Choose "Deploy from a branch".
5. Select the main branch and `/ (root)`.
6. Open the generated GitHub Pages URL.

## Setup Firebase

1. Create a Firebase project.
2. Add a Web App.
3. Enable Authentication → Email/Password.
4. Create the admin account in Firebase Authentication.
5. Create Firestore Database.
6. Paste the Firebase Web App configuration into:
   `assets/js/app.js`
7. Add the security rules from `firebase-security-rules.txt`.
8. For production, replace the starter rules with an admin custom-claims/allowlist model.

## Real-time schedule management

The frontend already listens to:
- `liveUpdates`
- `schedule`

For a fully editable schedule manager, create a small admin form that writes documents to the `schedule` collection. The same Firebase listener can then update all attendees without a page refresh.

## Delegate assignments

For production, create an `assignments` Firestore collection with fields:
- name
- email
- committee
- country
- role

The current file includes demo assignments so the UI can be tested immediately.

## Resource PDFs

Place official PDF files in:
`assets/resources/`

Then update the resource list in `assets/js/app.js`.

The "Download Combined PDF" button fetches those PDFs and merges them in the browser using pdf-lib.

## Gmail

The registration form uses:
`unsccrisismun2026@gmail.com`

If Firebase is connected, registrations are saved to Firestore.
If Firebase is not connected, the form opens a pre-filled Gmail/mail client email.

For true automatic Gmail sending and confirmation emails, use a server-side service or Google Apps Script. Never put a Gmail password or private API credential in GitHub Pages JavaScript.

## Recommended production upgrades

- Firebase custom claims for admin roles
- Admin-only assignment editor
- Admin schedule editor
- Admin registration dashboard
- CSV export
- Delegate-specific login rather than email-only lookup
- Email confirmation through a server-side email service
- PDF upload interface using Firebase Storage
- Audit log for admin changes
