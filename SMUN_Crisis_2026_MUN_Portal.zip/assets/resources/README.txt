Put your official committee PDFs in this folder. The filenames referenced by assets/js/app.js are placeholders until you add the real PDFs.
