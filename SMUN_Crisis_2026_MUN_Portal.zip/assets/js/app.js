/*
  SMUN CRISIS 2026
  Static GitHub Pages frontend + optional Firebase realtime backend.
  IMPORTANT: Firebase Web API keys are identifiers, not passwords. Protect access with Firebase Security Rules.
*/
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import { getFirestore, collection, addDoc, onSnapshot, query, orderBy, limit } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";

/* Paste your Firebase Web App config here after creating a Firebase project. */
const FIREBASE_CONFIG = {
  apiKey: "PASTE_FIREBASE_API_KEY",
  authDomain: "PASTE_PROJECT.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT.firebasestorage.app",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};

const USE_FIREBASE = !Object.values(FIREBASE_CONFIG).some(v => String(v).includes("PASTE_"));

let db=null, auth=null;
if(USE_FIREBASE){
  try{
    const app=initializeApp(FIREBASE_CONFIG);
    auth=getAuth(app); db=getFirestore(app);
  }catch(e){console.warn("Firebase disabled:",e)}
}

const committees = [
  {id:"nixon",name:"Nixon War Cabinet",type:"Crisis Cabinet",agenda:"The Watergate Crisis and the fight for political survival",freeze:"7 August 1974",desc:"A high-pressure executive cabinet where every decision can reshape the final days of the Nixon presidency."},
  {id:"unsc",name:"United Nations Security Council",type:"Security Council",agenda:"Crisis in international peace and security",freeze:"31 October 2026",desc:"A fast-moving council built around emergency diplomacy, negotiations and binding resolutions."},
  {id:"disec",name:"UNGA-DISEC",type:"General Assembly",agenda:"Addressing the Proliferation of Conventional Weapons and Its Impact on International Peace and Security",freeze:"1 January 1985",desc:"Debate arms transfers, illicit proliferation, regional instability and international controls."},
  {id:"oic",name:"OIC",type:"Regional / Crisis",agenda:"Political stability, cooperation and collective action",freeze:"Conference freeze",desc:"Coordinate positions, manage regional interests and build consensus among member states."},
  {id:"lon",name:"League of Nations",type:"Historical Committee",agenda:"Collective security and the survival of the League",freeze:"Historical freeze",desc:"A historical simulation where delegates confront the structural crises threatening the League."}
];

const assignments = [
  {name:"Demo Delegate",email:"delegate@example.com",committee:"UNGA-DISEC",country:"United Arab Emirates",role:"Delegate"},
  {name:"Demo Delegate 2",email:"delegate2@example.com",committee:"UNSC",country:"France",role:"Delegate"},
  {name:"Demo Delegate 3",email:"delegate3@example.com",committee:"OIC",country:"Türkiye",role:"Delegate"},
  {name:"Demo Delegate 4",email:"delegate4@example.com",committee:"League of Nations",country:"United Kingdom",role:"Delegate"}
];

const scheduleFallback=[
  {time:"09:00",day:"DAY 01",title:"Opening Ceremony",body:"Welcome, rules, introductions and conference briefing."},
  {time:"10:00",day:"DAY 01",title:"Committee Session I",body:"Formal session begins."},
  {time:"13:00",day:"DAY 01",title:"Break",body:"Delegate break."},
  {time:"14:00",day:"DAY 01",title:"Committee Session II",body:"Debate and moderated caucuses."},
  {time:"18:00",day:"DAY 01",title:"Crisis / Committee Update",body:"Live developments and committee work."},
  {time:"09:00",day:"DAY 02",title:"Committee Session III",body:"Negotiations and drafting."},
  {time:"13:00",day:"DAY 02",title:"Resolution Submission",body:"Final paperwork submission window."},
  {time:"15:00",day:"DAY 02",title:"Closing Ceremony",body:"Awards, acknowledgements and closing remarks."}
];

const resources=[
  {committee:"UNGA-DISEC",title:"Delegate Guide",file:"assets/resources/unga-disec-delegate-guide.pdf",desc:"Rules, portfolio briefing and preparation guide."},
  {committee:"UNSC",title:"Committee Background Guide",file:"assets/resources/unsc-background-guide.pdf",desc:"Agenda background and council briefing."},
  {committee:"Nixon War Cabinet",title:"Crisis Brief",file:"assets/resources/nixon-war-cabinet-brief.pdf",desc:"Historical context and crisis preparation."},
  {committee:"OIC",title:"Committee Background",file:"assets/resources/oic-background-guide.pdf",desc:"Committee mandate and agenda briefing."},
  {committee:"League of Nations",title:"Historical Brief",file:"assets/resources/league-of-nations-guide.pdf",desc:"Historical context and committee procedure."}
];

const $=id=>document.getElementById(id);
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2800)}
function escapeHTML(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

function renderCommittees(){
  $("committeeGrid").innerHTML=committees.map((c,i)=>`
    <article class="committee-card">
      <div><span class="num">COMMITTEE ${String(i+1).padStart(2,"0")}</span>
      <h3>${escapeHTML(c.name)}</h3><p>${escapeHTML(c.desc)}</p></div>
      <div><span class="tag">${escapeHTML(c.type)}</span><span class="tag">FREEZE: ${escapeHTML(c.freeze)}</span>
      <p><b>Agenda:</b> ${escapeHTML(c.agenda)}</p></div>
    </article>`).join("");
}
function renderAssignments(list=assignments){
  $("assignmentGrid").innerHTML=list.length?list.map(a=>`
    <article class="assignment-card"><strong>${escapeHTML(a.name)}</strong>
    <span>${escapeHTML(a.email)}</span><span>${escapeHTML(a.committee)}</span>
    <div class="country">${escapeHTML(a.country)}</div><span>${escapeHTML(a.role||"Delegate")}</span></article>`).join("")
    : `<p class="small-note">No matching assignment found.</p>`;
}
function renderSchedule(list=scheduleFallback){
  $("scheduleList").innerHTML=list.map(x=>`<div class="time-item"><time>${escapeHTML(x.day)} · ${escapeHTML(x.time)}</time><div><h3>${escapeHTML(x.title)}</h3><p>${escapeHTML(x.body)}</p></div></div>`).join("");
}
function renderResources(){
  const sel=$("resourceCommittee");sel.innerHTML='<option value="all">All committees</option>'+[...new Set(resources.map(r=>r.committee))].map(c=>`<option>${escapeHTML(c)}</option>`).join("");
  const draw=()=>{const filter=sel.value;const list=filter==="all"?resources:resources.filter(r=>r.committee===filter);
    $("resourceGrid").innerHTML=list.map(r=>`<article class="resource-card"><span class="tag">${escapeHTML(r.committee)}</span><h3>${escapeHTML(r.title)}</h3><p>${escapeHTML(r.desc)}</p><a href="${r.file}" target="_blank" rel="noopener">OPEN / DOWNLOAD ↗</a></article>`).join("")};
  sel.onchange=draw;draw();
}
function renderLive(items){
  $("liveFeed").innerHTML=items.length?items.map(x=>`<article class="live-item"><div class="meta">${escapeHTML(x.type||"GENERAL")} · ${escapeHTML(x.createdAt||"")}</div><h3>${escapeHTML(x.title)}</h3><p>${escapeHTML(x.body)}</p></article>`).join(""):`<article class="live-item"><div class="meta">SYSTEM</div><h3>No live updates yet.</h3><p>The organising committee can publish updates here once Firebase is connected.</p></article>`;
  if(items[0]) $("tickerText").textContent=items[0].title+" — "+items[0].body;
}
function lookupDelegate(){
  const email=$("portalEmail").value.trim().toLowerCase();
  const found=assignments.find(a=>a.email.toLowerCase()===email);
  $("portalResult").innerHTML=found?`<div class="success"><b>${escapeHTML(found.name)}</b><br>${escapeHTML(found.committee)} · ${escapeHTML(found.country)}<br><span>${escapeHTML(found.role)}</span></div>`:`<p class="small-note">No portfolio found. Please use the email used during registration.</p>`;
}
window.lookupDelegate=lookupDelegate;
window.toggleMenu=()=>{const n=$("nav");n.style.display=n.style.display==="flex"?"none":"flex"};
window.logoutAdmin=async()=>{if(auth){await signOut(auth);toast("Signed out.");}};

async function setupFirebase(){
  if(!USE_FIREBASE||!db||!auth){renderLive([]);return;}
  onAuthStateChanged(auth,user=>{
    $("adminStatus").textContent=user?`Signed in as ${user.email}`:"Not signed in";
    $("adminPanel").classList.toggle("hidden",!user);
  });
  const liveQ=query(collection(db,"liveUpdates"),orderBy("createdAt","desc"),limit(30));
  onSnapshot(liveQ,snap=>{
    const data=snap.docs.map(d=>({id:d.id,...d.data(),createdAt:d.data().createdAt?.toDate?.().toLocaleString?.()||""}));
    renderLive(data);
  },()=>renderLive([]));
}
$("adminLogin").addEventListener("submit",async e=>{
  e.preventDefault();
  if(!auth){toast("Connect Firebase first.");return;}
  try{await signInWithEmailAndPassword(auth,$("adminEmail").value,$("adminPassword").value);toast("Admin signed in.");}
  catch(err){toast("Login failed. Check Firebase Auth credentials.");}
});
$("updateForm").addEventListener("submit",async e=>{
  e.preventDefault(); if(!db||!auth?.currentUser){toast("Admin login required.");return;}
  await addDoc(collection(db,"liveUpdates"),{title:$("updateTitle").value,body:$("updateBody").value,type:$("updateType").value,createdAt:new Date()});
  e.target.reset();toast("Live update published.");
});
$("registrationForm").addEventListener("submit",async e=>{
  e.preventDefault(); const data=Object.fromEntries(new FormData(e.target).entries());
  if(db){try{await addDoc(collection(db,"registrations"),{...data,createdAt:new Date()});toast("Registration submitted.");e.target.reset();return;}catch(err){console.warn(err)}}
  const subject=encodeURIComponent("SMUN Crisis 2026 Registration — "+data.name);
  const body=encodeURIComponent(`Name: ${data.name}\nEmail: ${data.email}\nSchool: ${data.school}\nExperience: ${data.experience}\nCommittee preference: ${data.preference}`);
  window.location.href=`mailto:unsccrisismun2026@gmail.com?subject=${subject}&body=${body}`;
});
$("assignmentSearch").addEventListener("input",e=>{
  const q=e.target.value.toLowerCase();
  renderAssignments(assignments.filter(a=>Object.values(a).some(v=>String(v).toLowerCase().includes(q))));
});
async function downloadCombinedPDF(){
  const filter=$("resourceCommittee").value;
  const list=filter==="all"?resources:resources.filter(r=>r.committee===filter);
  if(!window.PDFLib){toast("PDF utility loading — try again.");return;}
  const {PDFDocument}=window.PDFLib; const merged=await PDFDocument.create(); let count=0;
  for(const r of list){try{const res=await fetch(r.file);if(!res.ok)continue;const bytes=await res.arrayBuffer();const src=await PDFDocument.load(bytes);const pages=await merged.copyPages(src,src.getPageIndices());pages.forEach(p=>merged.addPage(p));count+=pages.length;}catch(err){console.warn("Skipping",r.file,err)}}
  if(!count){toast("No PDF files found yet. Add them to assets/resources/.");return;}
  const bytes=await merged.save();const blob=new Blob([bytes],{type:"application/pdf"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=(filter==="all"?"SMUN-Combined-Resources":filter.replaceAll(" ","-")+"-Resources")+".pdf";a.click();URL.revokeObjectURL(a.href);
}
window.downloadCombinedPDF=downloadCombinedPDF;

renderCommittees();renderAssignments();renderSchedule();renderResources();setupFirebase();
